import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { Calendar, TrendingUp, TrendingDown } from 'lucide-react-native';
import { BudgetCard } from '@/components/BudgetCard';
import { ExpenseCard } from '@/components/ExpenseCard';
import { useExpenses } from '@/hooks/useExpenses';
import { formatCurrency } from '@/utils/currency';

export default function HomeScreen() {
  const { expenses, loading, deleteExpense, getBudgetInfo, refreshExpenses } = useExpenses();
  const [refreshing, setRefreshing] = useState(false);

  const budgetInfo = getBudgetInfo();
  const recentExpenses = expenses.slice(0, 5);
  
  const todayExpenses = expenses.filter(expense => {
    const today = new Date();
    const expenseDate = new Date(expense.date);
    return expenseDate.toDateString() === today.toDateString();
  });

  const todayTotal = todayExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshExpenses();
    setRefreshing(false);
  };

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={styles.header}>
        <Text style={styles.greeting}>Hello, Kavya!</Text>
        <Text style={styles.subtitle}>Track your expenses smartly</Text>
      </View>

      <BudgetCard budgetInfo={budgetInfo} />

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Calendar size={24} color="#22c55e" />
          <Text style={styles.statLabel}>Today's Expenses</Text>
          <Text style={styles.statValue}>{formatCurrency(todayTotal)}</Text>
        </View>

        <View style={styles.statCard}>
          <TrendingUp size={24} color="#f59e0b" />
          <Text style={styles.statLabel}>This Month</Text>
          <Text style={styles.statValue}>{formatCurrency(budgetInfo.spent)}</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Expenses</Text>
        {recentExpenses.length === 0 ? (
          <View style={styles.emptyState}>
            <TrendingDown size={48} color="#9ca3af" />
            <Text style={styles.emptyText}>No expenses yet</Text>
            <Text style={styles.emptySubtext}>Start tracking your expenses by adding your first transaction</Text>
          </View>
        ) : (
          recentExpenses.map((expense) => (
            <ExpenseCard
              key={expense.id}
              expense={expense}
              onDelete={deleteExpense}
            />
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#22c55e',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#dcfce7',
    fontWeight: '500',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginTop: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 8,
    marginBottom: 4,
    textAlign: 'center',
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#111827',
  },
  section: {
    marginTop: 24,
    paddingBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#6b7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#9ca3af',
    textAlign: 'center',
    lineHeight: 20,
  },
});