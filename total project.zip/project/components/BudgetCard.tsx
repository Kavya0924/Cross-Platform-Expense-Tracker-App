import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { BudgetInfo } from '@/types/expense';
import { formatCurrency } from '@/utils/currency';

interface BudgetCardProps {
  budgetInfo: BudgetInfo;
}

export const BudgetCard: React.FC<BudgetCardProps> = ({ budgetInfo }) => {
  const { spent, remaining, percentage, limit } = budgetInfo;
  
  const getProgressColor = () => {
    if (percentage <= 60) return '#22c55e';
    if (percentage <= 80) return '#f59e0b';
    return '#ef4444';
  };

  const getBackgroundColor = () => {
    if (percentage <= 60) return '#dcfce7';
    if (percentage <= 80) return '#fef3c7';
    return '#fee2e2';
  };

  return (
    <View style={[styles.container, { backgroundColor: getBackgroundColor() }]}>
      <Text style={styles.title}>Monthly Budget</Text>
      
      <View style={styles.amountContainer}>
        <Text style={styles.spentAmount}>{formatCurrency(spent)}</Text>
        <Text style={styles.limitText}>of {formatCurrency(limit)}</Text>
      </View>

      <View style={styles.progressContainer}>
        <View style={styles.progressBackground}>
          <View 
            style={[
              styles.progressBar, 
              { 
                width: `${Math.min(100, percentage)}%`,
                backgroundColor: getProgressColor()
              }
            ]} 
          />
        </View>
        <Text style={styles.percentageText}>{percentage.toFixed(1)}%</Text>
      </View>

      <View style={styles.remainingContainer}>
        <Text style={[styles.remainingText, { color: getProgressColor() }]}>
          {remaining > 0 ? `${formatCurrency(remaining)} remaining` : 'Budget exceeded!'}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 16,
    marginHorizontal: 16,
    marginVertical: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  amountContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 16,
  },
  spentAmount: {
    fontSize: 32,
    fontWeight: '700',
    color: '#111827',
    marginRight: 8,
  },
  limitText: {
    fontSize: 16,
    color: '#6b7280',
    fontWeight: '500',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressBackground: {
    flex: 1,
    height: 8,
    backgroundColor: '#e5e7eb',
    borderRadius: 4,
    marginRight: 12,
  },
  progressBar: {
    height: '100%',
    borderRadius: 4,
  },
  percentageText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    width: 45,
  },
  remainingContainer: {
    alignItems: 'center',
  },
  remainingText: {
    fontSize: 14,
    fontWeight: '600',
  },
});