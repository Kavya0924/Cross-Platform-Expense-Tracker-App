export interface Expense {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface BudgetInfo {
  limit: number;
  spent: number;
  remaining: number;
  percentage: number;
}