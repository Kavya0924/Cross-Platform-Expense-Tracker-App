import AsyncStorage from '@react-native-async-storage/async-storage';
import { Expense } from '@/types/expense';

const EXPENSES_KEY = 'expenses';

// Sample expenses for demonstration
const SAMPLE_EXPENSES: Expense[] = [
  {
    id: '1',
    amount: 850,
    category: 'shopping',
    description: 'Grocery shopping at Big Bazaar',
    date: new Date(2025, 0, 15).toISOString(),
    createdAt: new Date(2025, 0, 15).toISOString(),
  },
  {
    id: '2',
    amount: 120,
    category: 'transport',
    description: 'Auto rickshaw to office',
    date: new Date(2025, 0, 14).toISOString(),
    createdAt: new Date(2025, 0, 14).toISOString(),
  },
  {
    id: '3',
    amount: 450,
    category: 'food',
    description: 'Dinner at restaurant with friends',
    date: new Date(2025, 0, 13).toISOString(),
    createdAt: new Date(2025, 0, 13).toISOString(),
  },
  {
    id: '4',
    amount: 300,
    category: 'entertainment',
    description: 'Movie tickets for weekend show',
    date: new Date(2025, 0, 12).toISOString(),
    createdAt: new Date(2025, 0, 12).toISOString(),
  },
  {
    id: '5',
    amount: 680,
    category: 'bills',
    description: 'Mobile phone bill payment',
    date: new Date(2025, 0, 11).toISOString(),
    createdAt: new Date(2025, 0, 11).toISOString(),
  },
  {
    id: '6',
    amount: 200,
    category: 'transport',
    description: 'Metro card recharge',
    date: new Date(2025, 0, 10).toISOString(),
    createdAt: new Date(2025, 0, 10).toISOString(),
  },
  {
    id: '7',
    amount: 150,
    category: 'food',
    description: 'Coffee and snacks',
    date: new Date(2025, 0, 9).toISOString(),
    createdAt: new Date(2025, 0, 9).toISOString(),
  },
  {
    id: '8',
    amount: 250,
    category: 'healthcare',
    description: 'Pharmacy medicines',
    date: new Date(2025, 0, 8).toISOString(),
    createdAt: new Date(2025, 0, 8).toISOString(),
  },
  {
    id: '9',
    amount: 320,
    category: 'shopping',
    description: 'Clothing purchase at mall',
    date: new Date(2025, 0, 7).toISOString(),
    createdAt: new Date(2025, 0, 7).toISOString(),
  },
  {
    id: '10',
    amount: 180,
    category: 'transport',
    description: 'Uber ride to airport',
    date: new Date(2025, 0, 6).toISOString(),
    createdAt: new Date(2025, 0, 6).toISOString(),
  },
  {
    id: '11',
    amount: 280,
    category: 'food',
    description: 'Lunch with colleagues',
    date: new Date(2025, 0, 5).toISOString(),
    createdAt: new Date(2025, 0, 5).toISOString(),
  },
  {
    id: '12',
    amount: 150,
    category: 'entertainment',
    description: 'Gaming subscription',
    date: new Date(2025, 0, 4).toISOString(),
    createdAt: new Date(2025, 0, 4).toISOString(),
  },
  {
    id: '13',
    amount: 400,
    category: 'bills',
    description: 'Internet bill payment',
    date: new Date(2025, 0, 3).toISOString(),
    createdAt: new Date(2025, 0, 3).toISOString(),
  },
  {
    id: '14',
    amount: 90,
    category: 'transport',
    description: 'Bus pass monthly',
    date: new Date(2025, 0, 2).toISOString(),
    createdAt: new Date(2025, 0, 2).toISOString(),
  },
  {
    id: '15',
    amount: 220,
    category: 'food',
    description: 'Breakfast and tea',
    date: new Date(2025, 0, 1).toISOString(),
    createdAt: new Date(2025, 0, 1).toISOString(),
  },
  {
    id: '16',
    amount: 350,
    category: 'healthcare',
    description: 'Doctor consultation',
    date: new Date(2024, 11, 30).toISOString(),
    createdAt: new Date(2024, 11, 30).toISOString(),
  },
  {
    id: '17',
    amount: 180,
    category: 'others',
    description: 'Gift for friend',
    date: new Date(2024, 11, 29).toISOString(),
    createdAt: new Date(2024, 11, 29).toISOString(),
  },
  {
    id: '18',
    amount: 120,
    category: 'education',
    description: 'Online course subscription',
    date: new Date(2024, 11, 28).toISOString(),
    createdAt: new Date(2024, 11, 28).toISOString(),
  },
];
export const saveExpenses = async (expenses: Expense[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(EXPENSES_KEY, JSON.stringify(expenses));
  } catch (error) {
    console.error('Error saving expenses:', error);
  }
};

export const loadExpenses = async (): Promise<Expense[]> => {
  try {
    const expensesJson = await AsyncStorage.getItem(EXPENSES_KEY);
    if (expensesJson) {
      return JSON.parse(expensesJson);
    } else {
      // Initialize with sample data if no expenses exist
      await saveExpenses(SAMPLE_EXPENSES);
      return SAMPLE_EXPENSES;
    }
  } catch (error) {
    console.error('Error loading expenses:', error);
    return SAMPLE_EXPENSES;
  }
};

export const addExpense = async (expense: Expense): Promise<void> => {
  try {
    const expenses = await loadExpenses();
    expenses.push(expense);
    await saveExpenses(expenses);
  } catch (error) {
    console.error('Error adding expense:', error);
  }
};

export const deleteExpense = async (expenseId: string): Promise<void> => {
  try {
    const expenses = await loadExpenses();
    const filteredExpenses = expenses.filter(expense => expense.id !== expenseId);
    await saveExpenses(filteredExpenses);
  } catch (error) {
    console.error('Error deleting expense:', error);
  }
};